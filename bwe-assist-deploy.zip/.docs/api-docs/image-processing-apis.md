# Image Processing APIs Documentation

## ImgBB API
- **API Key**: IMGBB_API_KEY
- **Documentation**: https://api.imgbb.com/
- **Main Endpoints**:
  - Upload Image: `POST /1/upload`
  - Delete Image: `DELETE /1/images/{id}`

## PixelCut API
- **API Key**: PIXELCUT_API_KEY
- **Documentation**: https://www.pixelcut.ai/api
- **Main Features**:
  - Background Removal
  - Image Enhancement
  - Object Detection
