# OpenAI API Documentation

## Overview
OpenAI provides a powerful suite of AI models accessible through REST APIs. This documentation covers all aspects of integrating with OpenAI's services, including GPT models, DALL-E, and embeddings.

## Authentication
```python
import os
from openai import OpenAI

# Initialize the client with your API key
client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))
```

## API Endpoints

### 1. Chat Completions
```python
def get_chat_completion(
    messages,
    model="gpt-4",
    temperature=0.7,
    max_tokens=None,
    stream=False
):
    """
    Generate chat completions using GPT models.
    """
    response = client.chat.completions.create(
        model=model,
        messages=messages,
        temperature=temperature,
        max_tokens=max_tokens,
        stream=stream
    )
    return response

# Example usage
messages = [
    {"role": "system", "content": "You are a helpful assistant."},
    {"role": "user", "content": "What is machine learning?"}
]
response = get_chat_completion(messages)
```

### 2. Image Generation (DALL-E)
```python
def generate_image(
    prompt,
    size="1024x1024",
    quality="standard",
    n=1,
    model="dall-e-3"
):
    """
    Generate images using DALL-E.
    """
    response = client.images.generate(
        model=model,
        prompt=prompt,
        size=size,
        quality=quality,
        n=n
    )
    return response

# Example usage
images = generate_image(
    "A serene landscape with mountains at sunset"
)
```

### 3. Embeddings
```python
def get_embedding(
    text,
    model="text-embedding-3-small"
):
    """
    Generate embeddings for text.
    """
    response = client.embeddings.create(
        model=model,
        input=text
    )
    return response

# Example usage
embedding = get_embedding("The quick brown fox jumps over the lazy dog")
```

### 4. Audio Transcription
```python
def transcribe_audio(
    audio_file,
    model="whisper-1",
    response_format="text"
):
    """
    Transcribe audio using Whisper.
    """
    with open(audio_file, "rb") as file:
        response = client.audio.transcriptions.create(
            model=model,
            file=file,
            response_format=response_format
        )
    return response

# Example usage
transcript = transcribe_audio("speech.mp3")
```

## Error Handling
```python
class OpenAIError(Exception):
    pass

def handle_openai_request(func):
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except Exception as e:
            if "Rate limit" in str(e):
                raise OpenAIError("Rate limit exceeded")
            elif "Invalid API key" in str(e):
                raise OpenAIError("Authentication failed")
            elif "Maximum context length" in str(e):
                raise OpenAIError("Context length exceeded")
            else:
                raise OpenAIError(f"OpenAI error: {str(e)}")
    return wrapper

@handle_openai_request
def safe_chat_completion(messages):
    return get_chat_completion(messages)
```

## Rate Limits
- Varies by model and tier
- TPM (Tokens Per Minute) limits
- RPM (Requests Per Minute) limits
- Concurrent request limits

## Best Practices

### 1. Token Management
```python
def manage_conversation_tokens(
    messages,
    max_tokens=4000,
    model="gpt-4"
):
    """
    Manage conversation tokens to prevent context length errors.
    """
    from tiktoken import encoding_for_model
    
    enc = encoding_for_model(model)
    total_tokens = 0
    managed_messages = []
    
    for message in reversed(messages):
        message_tokens = len(enc.encode(message["content"]))
        if total_tokens + message_tokens <= max_tokens:
            managed_messages.insert(0, message)
            total_tokens += message_tokens
        else:
            break
    
    return managed_messages
```

### 2. Streaming Responses
```python
def stream_chat_completion(messages, callback=None):
    """
    Stream chat completions with optional callback.
    """
    stream = client.chat.completions.create(
        model="gpt-4",
        messages=messages,
        stream=True
    )
    
    collected_chunks = []
    for chunk in stream:
        if chunk.choices[0].delta.content is not None:
            collected_chunks.append(chunk.choices[0].delta.content)
            if callback:
                callback(chunk.choices[0].delta.content)
    
    return "".join(collected_chunks)
```

### 3. Cost Optimization
```python
def optimize_api_usage(text, task):
    """
    Optimize API usage based on task requirements.
    """
    models = {
        "simple": "gpt-3.5-turbo",
        "complex": "gpt-4",
        "embedding": "text-embedding-3-small",
        "image": "dall-e-3"
    }
    
    if task == "classification":
        return get_chat_completion(
            messages=[{"role": "user", "content": text}],
            model=models["simple"],
            temperature=0.3
        )
    elif task == "creative":
        return get_chat_completion(
            messages=[{"role": "user", "content": text}],
            model=models["complex"],
            temperature=0.8
        )
    elif task == "embedding":
        return get_embedding(text, model=models["embedding"])
```

## Common Use Cases

### 1. Content Generation
```python
def generate_content(topic, style="professional", max_words=500):
    """
    Generate content with specific style and length.
    """
    prompt = f"""
    Write a {style} article about {topic}.
    Target length: {max_words} words.
    Include:
    1. Introduction
    2. Main points
    3. Conclusion
    """
    
    response = safe_chat_completion([
        {"role": "user", "content": prompt}
    ])
    return response
```

### 2. Code Generation
```python
def generate_code(description, language="python"):
    """
    Generate code with explanation.
    """
    prompt = f"""
    Write {language} code that accomplishes the following:
    {description}
    
    Provide:
    1. Complete, working code
    2. Brief explanation
    3. Example usage
    """
    
    response = safe_chat_completion([
        {"role": "system", "content": "You are an expert programmer."},
        {"role": "user", "content": prompt}
    ])
    return response
```

### 3. Image Generation Pipeline
```python
def generate_image_variations(
    base_prompt,
    styles=["realistic", "artistic", "minimalist"],
    size="1024x1024"
):
    """
    Generate multiple image variations.
    """
    results = []
    for style in styles:
        prompt = f"{base_prompt} in {style} style"
        try:
            image = generate_image(prompt, size=size)
            results.append({
                "style": style,
                "image_url": image.data[0].url
            })
        except Exception as e:
            results.append({
                "style": style,
                "error": str(e)
            })
    return results
```

## Response Formats

### Chat Completion
```json
{
    "id": "chatcmpl-123abc",
    "object": "chat.completion",
    "created": 1677858242,
    "model": "gpt-4",
    "choices": [{
        "message": {
            "role": "assistant",
            "content": "Response content here"
        },
        "finish_reason": "stop",
        "index": 0
    }],
    "usage": {
        "prompt_tokens": 123,
        "completion_tokens": 456,
        "total_tokens": 579
    }
}
```

### Image Generation
```json
{
    "created": 1677858242,
    "data": [{
        "url": "https://...",
        "revised_prompt": "Revised prompt text"
    }]
}
```

## Security Considerations
1. Store API keys in environment variables
2. Implement rate limiting
3. Monitor usage and costs
4. Validate inputs and outputs
5. Handle sensitive information appropriately
6. Use secure connections
7. Implement proper error handling

## Model Capabilities

### GPT-4
- Complex reasoning
- Code generation
- Creative writing
- Technical analysis
- Multi-turn conversations

### GPT-3.5 Turbo
- Fast responses
- Cost-effective
- General tasks
- Basic coding
- Simple analysis

### DALL-E 3
- High-quality images
- Complex scenes
- Style variations
- Artistic control
- Photorealistic output

## Additional Resources
- [Official Documentation](https://platform.openai.com/docs)
- [API Reference](https://platform.openai.com/docs/api-reference)
- [Cookbook](https://github.com/openai/openai-cookbook)
- [Best Practices](https://platform.openai.com/docs/guides/best-practices)

## Support
- Help Center: help.openai.com
- Status Page: status.openai.com
- Documentation: platform.openai.com/docs
