# Zillow API Documentation (via RapidAPI)

## Overview
The Zillow API provides access to real estate data, property information, and market trends through RapidAPI. This documentation covers the integration with Zillow's API services.

## Authentication
```python
import os
import requests

RAPIDAPI_KEY = os.environ.get('RAPIDAPI_KEY')
BASE_URL = 'https://zillow56.p.rapidapi.com'

headers = {
    'X-RapidAPI-Key': RAPIDAPI_KEY,
    'X-RapidAPI-Host': 'zillow56.p.rapidapi.com'
}
```

## API Endpoints

### 1. Property Search
```python
def search_properties(
    location,
    price_min=None,
    price_max=None,
    beds_min=None,
    baths_min=None
):
    """
    Search for properties with various filters.
    """
    endpoint = f"{BASE_URL}/search"
    
    params = {
        'location': location,
        'price_min': price_min,
        'price_max': price_max,
        'beds_min': beds_min,
        'baths_min': baths_min
    }
    
    # Remove None values
    params = {k: v for k, v in params.items() if v is not None}
    
    response = requests.get(
        endpoint,
        headers=headers,
        params=params
    )
    return response.json()
```

### 2. Property Details
```python
def get_property_details(zpid):
    """
    Get detailed information about a specific property.
    """
    endpoint = f"{BASE_URL}/property"
    
    params = {
        'zpid': zpid
    }
    
    response = requests.get(
        endpoint,
        headers=headers,
        params=params
    )
    return response.json()
```

### 3. Property Photos
```python
def get_property_photos(zpid):
    """
    Get photos for a specific property.
    """
    endpoint = f"{BASE_URL}/photos"
    
    params = {
        'zpid': zpid
    }
    
    response = requests.get(
        endpoint,
        headers=headers,
        params=params
    )
    return response.json()
```

## Error Handling
```python
class ZillowAPIError(Exception):
    pass

def handle_zillow_response(response):
    """
    Handle API response and errors.
    """
    if response.status_code == 200:
        return response.json()
    
    error_messages = {
        401: "Invalid API key",
        403: "Forbidden - Check your API key and quota",
        404: "Resource not found",
        429: "Too many requests - Rate limit exceeded",
        500: "Internal server error",
        503: "Service unavailable"
    }
    
    error_msg = error_messages.get(
        response.status_code,
        f"Unknown error: {response.status_code}"
    )
    raise ZillowAPIError(error_msg)

def safe_api_call(func):
    """
    Decorator for safe API calls with error handling.
    """
    def wrapper(*args, **kwargs):
        try:
            response = func(*args, **kwargs)
            return handle_zillow_response(response)
        except requests.RequestException as e:
            raise ZillowAPIError(f"Network error: {str(e)}")
        except Exception as e:
            raise ZillowAPIError(f"Unexpected error: {str(e)}")
    return wrapper

@safe_api_call
def safe_property_search(location, **kwargs):
    return search_properties(location, **kwargs)
```

## Common Use Cases

### 1. Property Search with Filters
```python
def search_homes_for_sale(
    location,
    budget_max,
    min_beds=2,
    min_baths=2
):
    """
    Search for homes within budget and requirements.
    """
    try:
        results = safe_property_search(
            location=location,
            price_max=budget_max,
            beds_min=min_beds,
            baths_min=min_baths
        )
        
        # Process and filter results
        properties = []
        for prop in results.get('results', []):
            properties.append({
                'address': prop.get('address'),
                'price': prop.get('price'),
                'beds': prop.get('beds'),
                'baths': prop.get('baths'),
                'sqft': prop.get('sqft'),
                'zpid': prop.get('zpid')
            })
        
        return properties
    except ZillowAPIError as e:
        print(f"Error searching properties: {str(e)}")
        return []
```

### 2. Market Analysis
```python
def analyze_market(location, property_type='ALL'):
    """
    Analyze market trends for a location.
    """
    try:
        # Get recent sales
        recent_sales = safe_property_search(
            location=location,
            status='RECENTLY_SOLD'
        )
        
        # Get active listings
        active_listings = safe_property_search(
            location=location,
            status='FOR_SALE'
        )
        
        # Calculate metrics
        metrics = {
            'median_price': calculate_median_price(active_listings),
            'avg_days_on_market': calculate_avg_dom(active_listings),
            'price_per_sqft': calculate_price_per_sqft(active_listings),
            'recent_sales_count': len(recent_sales.get('results', [])),
            'active_listings_count': len(active_listings.get('results', []))
        }
        
        return metrics
    except ZillowAPIError as e:
        print(f"Error analyzing market: {str(e)}")
        return None
```

### 3. Property Comparison
```python
def compare_properties(zpid_list):
    """
    Compare multiple properties.
    """
    comparison = []
    
    for zpid in zpid_list:
        try:
            details = get_property_details(zpid)
            comparison.append({
                'address': details.get('address'),
                'price': details.get('price'),
                'price_per_sqft': details.get('price') / details.get('sqft'),
                'beds': details.get('beds'),
                'baths': details.get('baths'),
                'sqft': details.get('sqft'),
                'year_built': details.get('yearBuilt'),
                'lot_size': details.get('lotSize')
            })
        except ZillowAPIError as e:
            print(f"Error getting details for {zpid}: {str(e)}")
    
    return comparison
```

## Response Formats

### Property Search Response
```json
{
    "results": [
        {
            "zpid": "12345678",
            "address": {
                "streetAddress": "123 Main St",
                "city": "San Francisco",
                "state": "CA",
                "zipcode": "94105"
            },
            "price": 1200000,
            "beds": 3,
            "baths": 2,
            "sqft": 1500,
            "lot_size": 5000,
            "year_built": 1985,
            "status": "FOR_SALE"
        }
    ],
    "total_pages": 1,
    "total_results": 1
}
```

## Best Practices

### 1. Rate Limiting
```python
from time import sleep
from datetime import datetime, timedelta

class RateLimiter:
    def __init__(self, calls_per_second=1):
        self.calls_per_second = calls_per_second
        self.calls = []
    
    def wait(self):
        now = datetime.now()
        self.calls = [call for call in self.calls 
                     if call > now - timedelta(seconds=1)]
        
        if len(self.calls) >= self.calls_per_second:
            sleep(1)
        
        self.calls.append(now)

rate_limiter = RateLimiter()

def rate_limited_search(location, **kwargs):
    rate_limiter.wait()
    return safe_property_search(location, **kwargs)
```

### 2. Data Validation
```python
def validate_property_data(property_data):
    """
    Validate property data completeness and format.
    """
    required_fields = ['zpid', 'address', 'price']
    
    for field in required_fields:
        if field not in property_data:
            raise ValueError(f"Missing required field: {field}")
    
    if property_data.get('price', 0) <= 0:
        raise ValueError("Invalid price value")
    
    return True
```

## Security Considerations
1. Store API keys in environment variables
2. Implement rate limiting
3. Validate all inputs
4. Handle sensitive data appropriately
5. Use secure connections
6. Monitor usage and costs

## Additional Resources
- [RapidAPI Zillow Documentation](https://rapidapi.com/apimaker/api/zillow-com1/)
- [RapidAPI Dashboard](https://rapidapi.com/developer/dashboard)
- [Zillow Research](https://www.zillow.com/research/)

## Support
- RapidAPI Support: support@rapidapi.com
- Documentation: docs.rapidapi.com
- Status: status.rapidapi.com
