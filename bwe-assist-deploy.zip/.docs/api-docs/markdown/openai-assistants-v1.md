# OpenAI Assistants API Reference (v1)

## Overview

The OpenAI Assistants API allows you to build AI assistants that can call models and use tools to perform tasks.

## Endpoints

### Threads

#### Create Thread
- **Method**: POST
- **Endpoint**: `https://api.openai.com/v1/threads`
- **Description**: Creates a new thread.

**Request Body**:
- `messages` (array, optional): A list of messages to start the thread with.
- `metadata` (map, optional): Set of key-value pairs for storing additional information.

**Response**: Returns a thread object.

#### Retrieve Thread
- **Method**: GET
- **Endpoint**: `https://api.openai.com/v1/threads/{thread_id}`
- **Description**: Retrieves a thread by ID.

**Path Parameters**:
- `thread_id` (string, required): The ID of the thread to retrieve.

**Response**: Returns the thread object.

#### Modify Thread
- **Method**: POST
- **Endpoint**: `https://api.openai.com/v1/threads/{thread_id}`
- **Description**: Modifies a thread.

**Path Parameters**:
- `thread_id` (string, required): The ID of the thread to modify.

**Request Body**:
- `metadata` (map, optional): Set of key-value pairs to update.

**Response**: Returns the modified thread object.

#### Delete Thread
- **Method**: DELETE
- **Endpoint**: `https://api.openai.com/v1/threads/{thread_id}`
- **Description**: Deletes a thread.

**Path Parameters**:
- `thread_id` (string, required): The ID of the thread to delete.

**Response**: Returns deletion status.

### Messages

#### Create Message
- **Method**: POST
- **Endpoint**: `https://api.openai.com/v1/threads/{thread_id}/messages`
- **Description**: Creates a message in a thread.

**Path Parameters**:
- `thread_id` (string, required): The ID of the thread to create a message in.

**Request Body**:
- `role` (string, required): Either "user" or "assistant"
- `content` (string, required): The message content
- `file_ids` (array, optional): List of file IDs to attach
- `metadata` (map, optional): Additional metadata

**Response**: Returns a message object.

#### List Messages
- **Method**: GET
- **Endpoint**: `https://api.openai.com/v1/threads/{thread_id}/messages`
- **Description**: Lists all messages in a thread.

**Path Parameters**:
- `thread_id` (string, required): The ID of the thread.

**Query Parameters**:
- `limit` (integer, optional): Number of messages to return (1-100, default 20)
- `order` (string, optional): Sort order ("asc" or "desc")
- `after` (string, optional): Cursor for pagination
- `before` (string, optional): Cursor for pagination

**Response**: Returns a list of message objects.

### Runs

#### Create Run
- **Method**: POST
- **Endpoint**: `https://api.openai.com/v1/threads/{thread_id}/runs`
- **Description**: Creates a run within a thread.

**Path Parameters**:
- `thread_id` (string, required): The ID of the thread.

**Request Body**:
- `assistant_id` (string, required): The ID of the assistant to use
- `model` (string, optional): Override the assistant's model
- `instructions` (string, optional): Override the assistant's instructions
- `tools` (array, optional): Override the assistant's tools
- `metadata` (map, optional): Additional metadata

**Response**: Returns a run object.

#### List Runs
- **Method**: GET
- **Endpoint**: `https://api.openai.com/v1/threads/{thread_id}/runs`
- **Description**: Lists all runs in a thread.

**Path Parameters**:
- `thread_id` (string, required): The ID of the thread.

**Query Parameters**:
- `limit` (integer, optional): Number of runs to return (1-100, default 20)
- `order` (string, optional): Sort order ("asc" or "desc")
- `after` (string, optional): Cursor for pagination
- `before` (string, optional): Cursor for pagination

**Response**: Returns a list of run objects.

#### Retrieve Run
- **Method**: GET
- **Endpoint**: `https://api.openai.com/v1/threads/{thread_id}/runs/{run_id}`
- **Description**: Retrieves a specific run.

**Path Parameters**:
- `thread_id` (string, required): The ID of the thread
- `run_id` (string, required): The ID of the run

**Response**: Returns the run object.

#### Modify Run
- **Method**: POST
- **Endpoint**: `https://api.openai.com/v1/threads/{thread_id}/runs/{run_id}`
- **Description**: Modifies a run.

**Path Parameters**:
- `thread_id` (string, required): The ID of the thread
- `run_id` (string, required): The ID of the run

**Request Body**:
- `metadata` (map, optional): Additional metadata to update

**Response**: Returns the modified run object.

#### Cancel Run
- **Method**: POST
- **Endpoint**: `https://api.openai.com/v1/threads/{thread_id}/runs/{run_id}/cancel`
- **Description**: Cancels a run that is in progress.

**Path Parameters**:
- `thread_id` (string, required): The ID of the thread
- `run_id` (string, required): The ID of the run

**Response**: Returns the cancelled run object.

## Objects

### Thread Object
```json
{
  "id": "thread_abc123",
  "object": "thread",
  "created_at": 1698107661,
  "metadata": {}
}
```

### Message Object
```json
{
  "id": "msg_abc123",
  "object": "thread.message",
  "created_at": 1698983503,
  "thread_id": "thread_abc123",
  "role": "assistant",
  "content": [
    {
      "type": "text",
      "text": {
        "value": "Hi! How can I help you today?",
        "annotations": []
      }
    }
  ],
  "file_ids": [],
  "assistant_id": "asst_abc123",
  "run_id": "run_abc123",
  "metadata": {}
}
```

### Run Object
```json
{
  "id": "run_abc123",
  "object": "thread.run",
  "created_at": 1699075072,
  "assistant_id": "asst_abc123",
  "thread_id": "thread_abc123",
  "status": "completed",
  "started_at": 1699075072,
  "expires_at": null,
  "cancelled_at": null,
  "failed_at": null,
  "completed_at": 1699075073,
  "last_error": null,
  "model": "gpt-4-turbo",
  "instructions": null,
  "tools": [
    {
      "type": "code_interpreter"
    }
  ],
  "file_ids": [],
  "metadata": {},
  "usage": {
    "prompt_tokens": 123,
    "completion_tokens": 456,
    "total_tokens": 579
  }
}
```
