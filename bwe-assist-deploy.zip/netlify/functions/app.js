const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs');

// Ensure temp directory exists
const tmpDir = '/tmp';
if (!fs.existsSync(tmpDir)) {
  fs.mkdirSync(tmpDir);
}

exports.handler = async (event, context) => {
  try {
    // Set up environment variables
    process.env.PYTHONPATH = path.join(__dirname, '..', '..');
    
    // Spawn Python process
    const pythonProcess = spawn('python3', ['-c', `
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
from app import app
from flask import request
import json

# Ensure upload directory exists
os.makedirs('/tmp/uploads', exist_ok=True)

# Handle multipart form data for file uploads
${event.headers['content-type'] && event.headers['content-type'].includes('multipart/form-data') ? `
# Handle file upload
boundary = '${event.headers['content-type'].split('boundary=')[1]}'
parts = '${event.body}'.split(boundary)
file_path = None
for part in parts:
    if 'filename=' in part:
        filename = part.split('filename="')[1].split('"')[0]
        file_content = part.split('\\r\\n\\r\\n')[1].split('\\r\\n--')[0]
        
        # Save file to temp directory
        temp_path = '${path.join(tmpDir, filename)}'
        with open(temp_path, 'w') as f:
            f.write(file_content)
        
        # Update body to include file path
        body = '{{ "filename": "{}", "path": "{}" }}'.format(filename, temp_path)
    else:
        body = '${event.body || ''}'
` : `body = '${event.body || ''}'`}

# Set up the Flask request context
with app.test_request_context(
    path='${event.path.replace('/.netlify/functions/app', '')}',
    method='${event.httpMethod}',
    headers=${JSON.stringify(event.headers)},
    query_string=${JSON.stringify(event.queryStringParameters || {})},
    data=body
):
    response = app.full_dispatch_request()
    print(json.dumps({
        'status_code': response.status_code,
        'headers': dict(response.headers),
        'body': response.get_data(as_text=True)
    }))
    `]);

    // Handle response
    return new Promise((resolve, reject) => {
      let responseData = '';
      let errorData = '';

      pythonProcess.stdout.on('data', (data) => {
        responseData += data.toString();
      });

      pythonProcess.stderr.on('data', (data) => {
        errorData += data.toString();
      });

      pythonProcess.on('close', (code) => {
        if (code !== 0) {
          console.error('Python process error:', errorData);
          reject(new Error(errorData));
          return;
        }

        try {
          const response = JSON.parse(responseData);
          resolve({
            statusCode: response.status_code,
            headers: {
              'Content-Type': response.headers['Content-Type'] || 'text/html',
              'Access-Control-Allow-Origin': '*',
              'Access-Control-Allow-Headers': 'Content-Type',
              'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE'
            },
            body: response.body
          });
        } catch (error) {
          console.error('Error parsing Python response:', error);
          reject(error);
        }
      });
    });
  } catch (error) {
    console.error('Error:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Internal Server Error', details: error.message })
    };
  } finally {
    // Clean up temp files
    const files = fs.readdirSync(tmpDir);
    for (const file of files) {
      fs.unlinkSync(path.join(tmpDir, file));
    }
  }
};
