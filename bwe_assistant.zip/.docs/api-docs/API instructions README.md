# API Documentation Index

This directory contains official API documentation for various services used across projects.

## Available Documentation

### AI/ML APIs
1. **OpenAI API**
   - File: `openai-api.pdf`
   - Version: Latest
   - Description: Complete OpenAI API reference including Assistants API

### Cloud Services
1. **AWS Services** (To be added)
   - Expected files: 
     - `aws-s3-api.pdf`
     - `aws-lambda-api.pdf`
     - `aws-dynamodb-api.pdf`

2. **Google Cloud** (To be added)
   - Expected files:
     - `google-cloud-storage-api.pdf`
     - `google-cloud-functions-api.pdf`

### Development Tools
1. **GitHub API** (To be added)
   - Expected file: `github-api.pdf`
   - Description: GitHub REST and GraphQL API documentation

### Payment Processing
1. **Stripe** (To be added)
   - Expected file: `stripe-api.pdf`
   - Description: Complete Stripe payment processing API

### Communication
1. **Twilio** (To be added)
   - Expected file: `twilio-api.pdf`
   - Description: SMS, Voice, and Video API documentation

## How to Use

When starting a new project using the init script, these documents will be symbolically linked to your project's `.docs/api-docs/` directory. You can reference them when asking for help with API implementations.

## Adding New Documentation

1. Download the official PDF documentation
2. Place it in this directory
3. Update this README.md with the new entry
4. All new projects will automatically have access to the documentation

## Documentation Standards

- Keep only official documentation from trusted sources
- Use PDF format for consistency
- Name files clearly with the format: `service-name-api.pdf`
- Update this index whenever adding new documentation
