# ScrapingBee API Documentation

## Overview
ScrapingBee is a web scraping API that handles proxies, headless browsers, and CAPTCHAs. This documentation covers all aspects of integrating with ScrapingBee's API services.

## Authentication
```python
import os
import requests

API_KEY = os.environ.get('SCRAPINGBEE_API_KEY')
BASE_URL = 'https://app.scrapingbee.com/api/v1/'
```

## API Endpoints

### 1. Basic Web Scraping
```python
def scrape_webpage(url, render_js=False, premium_proxy=False):
    params = {
        'api_key': API_KEY,
        'url': url,
        'render_js': render_js,
        'premium_proxy': premium_proxy
    }
    
    response = requests.get(BASE_URL, params=params)
    return response.content
```

### 2. Advanced Scraping Features
```python
def advanced_scrape(url, options=None):
    if options is None:
        options = {}
    
    default_params = {
        'api_key': API_KEY,
        'url': url,
        'render_js': False,
        'premium_proxy': False,
        'country_code': '',
        'device': 'desktop',
        'wait': 0,
        'timeout': 30000
    }
    
    params = {**default_params, **options}
    response = requests.get(BASE_URL, params=params)
    return response.content
```

### 3. JavaScript Execution
```python
def execute_javascript(url, js_snippet):
    params = {
        'api_key': API_KEY,
        'url': url,
        'render_js': True,
        'js_snippet': js_snippet
    }
    
    response = requests.get(BASE_URL, params=params)
    return response.content
```

## Error Handling
```python
class ScrapingBeeError(Exception):
    pass

def handle_response(response):
    if response.status_code == 200:
        return response.content
    
    error_messages = {
        401: "Invalid API key",
        402: "Out of credits",
        403: "Forbidden",
        404: "URL not found",
        429: "Too many requests",
        500: "Internal server error",
        502: "Bad gateway",
        503: "Service unavailable"
    }
    
    error_msg = error_messages.get(
        response.status_code,
        f"Unknown error: {response.status_code}"
    )
    raise ScrapingBeeError(error_msg)

def safe_scrape(url, options=None):
    try:
        response = advanced_scrape(url, options)
        return handle_response(response)
    except requests.RequestException as e:
        raise ScrapingBeeError(f"Network error: {str(e)}")
```

## Rate Limits
- Concurrent requests: Based on plan
- Credits per month: Based on plan
- Request timeout: 30 seconds default

## Best Practices

### 1. Proxy Management
```python
def rotate_proxies(url, num_attempts=3):
    for attempt in range(num_attempts):
        try:
            response = advanced_scrape(url, {
                'premium_proxy': True,
                'country_code': 'random'
            })
            return handle_response(response)
        except ScrapingBeeError as e:
            if attempt == num_attempts - 1:
                raise e
            continue
```

### 2. Browser Automation
```python
def automate_browser(url, actions):
    js_code = """
    async () => {
        %s
        return document.documentElement.outerHTML;
    }
    """ % actions
    
    return execute_javascript(url, js_code)
```

## Common Use Cases

### 1. E-commerce Scraping
```python
def scrape_product(url):
    js_snippet = """
    () => {
        const product = {
            title: document.querySelector('h1').innerText,
            price: document.querySelector('.price').innerText,
            description: document.querySelector('.description').innerText,
            images: Array.from(
                document.querySelectorAll('.product-images img')
            ).map(img => img.src)
        };
        return JSON.stringify(product);
    }
    """
    
    return execute_javascript(url, js_snippet)
```

### 2. Data Extraction with Pagination
```python
def scrape_with_pagination(base_url, max_pages=5):
    all_data = []
    
    for page in range(1, max_pages + 1):
        url = f"{base_url}?page={page}"
        try:
            data = safe_scrape(url)
            if not data:
                break
            all_data.append(data)
        except ScrapingBeeError as e:
            print(f"Error on page {page}: {str(e)}")
            break
    
    return all_data
```

### 3. Geolocation-based Scraping
```python
def scrape_by_location(url, country_code):
    return advanced_scrape(url, {
        'country_code': country_code,
        'premium_proxy': True
    })
```

## Response Handling
```python
def process_response(response):
    try:
        # Handle different content types
        content_type = response.headers.get('content-type', '')
        
        if 'application/json' in content_type:
            return response.json()
        elif 'text/html' in content_type:
            return response.text
        elif 'application/pdf' in content_type:
            return response.content  # Binary content
        else:
            return response.content
    except Exception as e:
        raise ScrapingBeeError(f"Response processing error: {str(e)}")
```

## Security Considerations
1. Store API keys in environment variables
2. Implement rate limiting
3. Handle sensitive data appropriately
4. Respect robots.txt
5. Implement proper error handling
6. Monitor usage and costs

## Additional Features
1. Custom Headers
```python
def scrape_with_headers(url, headers):
    return advanced_scrape(url, {'headers': headers})
```

2. Cookie Management
```python
def scrape_with_cookies(url, cookies):
    return advanced_scrape(url, {'cookies': cookies})
```

3. Block Resources
```python
def scrape_efficiently(url):
    return advanced_scrape(url, {
        'block_resources': True,
        'block_ads': True
    })
```

## Additional Resources
- [Official Documentation](https://www.scrapingbee.com/docs/)
- [API Reference](https://www.scrapingbee.com/docs/api-reference/)
- [Use Cases](https://www.scrapingbee.com/use-cases/)
- [Blog](https://www.scrapingbee.com/blog/)

## Support
- Email: support@scrapingbee.com
- Documentation: docs.scrapingbee.com
- Status: status.scrapingbee.com
