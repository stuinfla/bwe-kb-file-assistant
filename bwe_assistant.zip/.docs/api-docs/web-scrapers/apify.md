# Apify API Documentation

## Overview
Apify is a powerful web scraping and automation platform that provides tools for building, running, and scaling web scraping actors. This documentation covers the integration with Apify's API services.

## Authentication
```python
import os
from apify_client import ApifyClient

# Initialize the client with your API token
client = ApifyClient(os.environ.get('APIFY_API_TOKEN'))
```

## API Endpoints

### 1. Actor Management
```python
def run_actor(actor_id, run_input=None):
    """Run an Apify actor with specified input."""
    run = client.actor(actor_id).call(run_input=run_input)
    return run

def get_actor_runs(actor_id, desc=True, limit=10):
    """Get list of actor runs."""
    runs = client.actor(actor_id).runs().list(desc=desc, limit=limit)
    return runs

def get_actor_info(actor_id):
    """Get information about an actor."""
    return client.actor(actor_id).get()
```

### 2. Dataset Operations
```python
def get_dataset_items(dataset_id, clean=False):
    """Get items from a dataset."""
    return client.dataset(dataset_id).list_items(clean=clean).items

def export_dataset(dataset_id, format='json'):
    """Export dataset in specified format."""
    return client.dataset(dataset_id).download_items(format=format)

def push_data_to_dataset(dataset_id, items):
    """Push items to a dataset."""
    return client.dataset(dataset_id).push_items(items)
```

### 3. Request Queue Management
```python
def create_request_queue(name=None):
    """Create a new request queue."""
    return client.request_queue().create(name=name)

def add_request(queue_id, request):
    """Add a request to the queue."""
    return client.request_queue(queue_id).add_request(request)

def get_request_queue_head(queue_id):
    """Get the next request from queue."""
    return client.request_queue(queue_id).get_head()
```

## Error Handling
```python
class ApifyError(Exception):
    pass

def handle_apify_request(func):
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except Exception as e:
            if 'Invalid token' in str(e):
                raise ApifyError("Authentication failed")
            elif 'Rate limit' in str(e):
                raise ApifyError("Rate limit exceeded")
            else:
                raise ApifyError(f"Apify error: {str(e)}")
    return wrapper

@handle_apify_request
def safe_actor_run(actor_id, run_input):
    return run_actor(actor_id, run_input)
```

## Common Use Cases

### 1. Web Scraping
```python
def scrape_website(url, custom_function=None):
    """
    Scrape a website using Apify's Cheerio Scraper
    """
    run_input = {
        "startUrls": [{"url": url}],
        "pageFunction": custom_function or """async function pageFunction(context) {
            const { request, log, $ } = context;
            return {
                url: request.url,
                title: $('title').text(),
                description: $('meta[name="description"]').attr('content'),
                text: $('body').text()
            };
        }""",
        "proxyConfiguration": {"useApifyProxy": True}
    }
    
    run = safe_actor_run('apify/cheerio-scraper', run_input)
    return client.dataset(run['defaultDatasetId']).list_items().items
```

### 2. Browser Automation
```python
def automate_browser(url, actions):
    """
    Automate browser actions using Puppeteer Scraper
    """
    run_input = {
        "startUrls": [{"url": url}],
        "pageFunction": f"""async function pageFunction(context) {{
            const {{ page }} = context;
            {actions}
            return await page.content();
        }}""",
        "proxyConfiguration": {"useApifyProxy": True}
    }
    
    run = safe_actor_run('apify/puppeteer-scraper', run_input)
    return client.dataset(run['defaultDatasetId']).list_items().items
```

### 3. Data Collection Pipeline
```python
def create_scraping_pipeline(urls, processing_actor_id):
    """
    Create a pipeline that scrapes URLs and processes the data
    """
    # First, scrape the URLs
    scrape_run = safe_actor_run('apify/cheerio-scraper', {
        "startUrls": [{"url": url} for url in urls]
    })
    
    # Then process the collected data
    process_run = safe_actor_run(processing_actor_id, {
        "datasetId": scrape_run['defaultDatasetId']
    })
    
    return process_run
```

## Best Practices

### 1. Resource Management
```python
def manage_storage():
    """Clean up old storage"""
    # List all datasets
    datasets = client.datasets().list()
    
    # Remove datasets older than 30 days
    for dataset in datasets.items:
        if (datetime.now() - dataset['createdAt']).days > 30:
            client.dataset(dataset['id']).delete()
```

### 2. Proxy Configuration
```python
def configure_proxy(country=None, session_id=None):
    """Configure proxy settings for actors"""
    proxy_config = {
        "useApifyProxy": True,
        "apifyProxyGroups": ["RESIDENTIAL"]
    }
    
    if country:
        proxy_config["apifyProxyCountry"] = country
    if session_id:
        proxy_config["apifyProxySessionId"] = session_id
    
    return proxy_config
```

## Response Formats
```json
{
    "id": "run_123abc",
    "actId": "actor_123",
    "startedAt": "2024-03-15T12:00:00.000Z",
    "finishedAt": "2024-03-15T12:01:00.000Z",
    "status": "SUCCEEDED",
    "defaultDatasetId": "dataset_123",
    "defaultRequestQueueId": "queue_123",
    "defaultKeyValueStoreId": "store_123"
}
```

## Security Considerations
1. Store API tokens securely
2. Implement rate limiting
3. Monitor resource usage
4. Handle sensitive data appropriately
5. Use secure connections
6. Implement proper error handling

## Advanced Features

### 1. Webhooks
```python
def setup_webhook(actor_id, webhook_url):
    """Set up a webhook for actor run notifications"""
    return client.webhooks().create({
        'actId': actor_id,
        'eventTypes': ['ACTOR.RUN.SUCCEEDED'],
        'requestUrl': webhook_url
    })
```

### 2. Key-Value Store
```python
def manage_key_value_store(store_id):
    """Manage key-value store operations"""
    # Set a value
    client.key_value_store(store_id).set_record('key', 'value')
    
    # Get a value
    record = client.key_value_store(store_id).get_record('key')
    
    # Delete a value
    client.key_value_store(store_id).delete_record('key')
```

## Additional Resources
- [Official Documentation](https://docs.apify.com/)
- [API Reference](https://docs.apify.com/api/v2)
- [SDK Documentation](https://docs.apify.com/sdk/python)
- [Examples](https://github.com/apify/apify-sdk-python/tree/master/examples)

## Support
- Email: support@apify.com
- Documentation: docs.apify.com
- Status: status.apify.com
- Community: community.apify.com
