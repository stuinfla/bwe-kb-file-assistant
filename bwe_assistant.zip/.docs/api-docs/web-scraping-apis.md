# Web Scraping APIs Documentation

## Apify API
- **API Key**: APIFY_API_KEY
- **Documentation**: https://docs.apify.com/api/v2
- **Main Features**:
  - Run Actors
  - Manage Datasets
  - Handle Web Scraping Tasks

## ScrapingBee API
- **API Key**: SCRAPING_BEE_API_KEY
- **Documentation**: https://www.scrapingbee.com/documentation
- **Main Features**:
  - Web Scraping
  - JavaScript Rendering
  - Proxy Management
