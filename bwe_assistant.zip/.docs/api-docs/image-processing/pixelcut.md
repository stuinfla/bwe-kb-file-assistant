# Pixelcut API Documentation

## Overview
Pixelcut provides AI-powered image editing and background removal services through their API, offering a comprehensive suite of image manipulation capabilities.

## Authentication
- API Key Required: Yes
- Key Format: Bearer Token
- Header Format: `Authorization: Bearer sk_YOUR_API_KEY`

## Base URL
```
https://api.pixelcut.ai/
```

## Key Endpoints

### Background Removal
#### Remove Background
- **Endpoint**: `POST /background-removal`
- **Description**: Remove background from images using AI
- **Headers**:
  - `Authorization`: Bearer token
  - `Content-Type`: multipart/form-data
- **Parameters**:
  - `image` (required): Image file or URL
  - `format` (optional): Output format (png/jpg)
  - `size` (optional): Output size
  - `crop` (optional): Auto-crop result (true/false)
  - `scale` (optional): Scale factor for output
  - `roi` (optional): Region of interest coordinates
- **Example Request**:
```python
import requests

def remove_background(image_path, output_format='png', crop=True):
    url = 'https://api.pixelcut.ai/background-removal'
    headers = {
        'Authorization': 'Bearer YOUR_API_KEY'
    }
    
    files = {
        'image': ('image.jpg', open(image_path, 'rb'), 'image/jpeg')
    }
    
    data = {
        'format': output_format,
        'crop': crop
    }
    
    response = requests.post(url, headers=headers, files=files, data=data)
    return response.json()
```

#### Replace Background
- **Endpoint**: `POST /background-replacement`
- **Description**: Replace image background with new background
- **Parameters**:
  - `image` (required): Original image file/URL
  - `background` (required): New background image/color
  - `blend_mode` (optional): Blending method (normal/multiply/screen)
  - `opacity` (optional): Background opacity (0-100)
  - `position` (optional): Background position (center/fill/fit)
  - `feather` (optional): Edge feathering radius
- **Example Request**:
```python
def replace_background(image_path, background_path, blend_mode='normal'):
    url = 'https://api.pixelcut.ai/background-replacement'
    headers = {
        'Authorization': 'Bearer YOUR_API_KEY'
    }
    
    files = {
        'image': ('image.jpg', open(image_path, 'rb'), 'image/jpeg'),
        'background': ('bg.jpg', open(background_path, 'rb'), 'image/jpeg')
    }
    
    data = {
        'blend_mode': blend_mode,
        'position': 'center'
    }
    
    response = requests.post(url, headers=headers, files=files, data=data)
    return response.json()
```

### Image Enhancement
#### Basic Enhancement
- **Endpoint**: `POST /enhance`
- **Description**: Enhance image quality using AI
- **Parameters**:
  - `image` (required): Image file/URL
  - `enhancement_type`: Type of enhancement
    - `quality`: Overall image quality
    - `color`: Color enhancement
    - `sharpness`: Image sharpness
    - `denoise`: Noise reduction
  - `strength` (optional): Enhancement strength (0-100)
- **Example Request**:
```python
def enhance_image(image_path, enhancement_type='quality', strength=50):
    url = 'https://api.pixelcut.ai/enhance'
    headers = {
        'Authorization': 'Bearer YOUR_API_KEY'
    }
    
    files = {
        'image': ('image.jpg', open(image_path, 'rb'), 'image/jpeg')
    }
    
    data = {
        'enhancement_type': enhancement_type,
        'strength': strength
    }
    
    response = requests.post(url, headers=headers, files=files, data=data)
    return response.json()
```

#### Portrait Enhancement
- **Endpoint**: `POST /portrait-enhance`
- **Description**: Enhance portrait photos
- **Parameters**:
  - `image` (required): Portrait image file/URL
  - `skin_smoothing` (optional): Skin smoothing level (0-100)
  - `eye_enhancement` (optional): Eye enhancement (true/false)
  - `teeth_whitening` (optional): Teeth whitening level (0-100)
  - `face_sculpting` (optional): Face sculpting options
- **Example Request**:
```python
def enhance_portrait(image_path, skin_smoothing=50, eye_enhancement=True):
    url = 'https://api.pixelcut.ai/portrait-enhance'
    headers = {
        'Authorization': 'Bearer YOUR_API_KEY'
    }
    
    files = {
        'image': ('image.jpg', open(image_path, 'rb'), 'image/jpeg')
    }
    
    data = {
        'skin_smoothing': skin_smoothing,
        'eye_enhancement': eye_enhancement
    }
    
    response = requests.post(url, headers=headers, files=files, data=data)
    return response.json()
```

### Object Manipulation
#### Object Removal
- **Endpoint**: `POST /object-removal`
- **Description**: Remove objects from images
- **Parameters**:
  - `image` (required): Image file/URL
  - `mask` (required): Mask indicating objects to remove
  - `fill_method` (optional): Content fill method (auto/extend/pattern)
- **Example Request**:
```python
def remove_object(image_path, mask_path):
    url = 'https://api.pixelcut.ai/object-removal'
    headers = {
        'Authorization': 'Bearer YOUR_API_KEY'
    }
    
    files = {
        'image': ('image.jpg', open(image_path, 'rb'), 'image/jpeg'),
        'mask': ('mask.png', open(mask_path, 'rb'), 'image/png')
    }
    
    data = {
        'fill_method': 'auto'
    }
    
    response = requests.post(url, headers=headers, files=files, data=data)
    return response.json()
```

#### Object Selection
- **Endpoint**: `POST /object-selection`
- **Description**: Automatically select objects in image
- **Parameters**:
  - `image` (required): Image file/URL
  - `selection_type`: Type of objects to select
    - `person`: Select people
    - `product`: Select products
    - `face`: Select faces
    - `text`: Select text
  - `multiple` (optional): Allow multiple selections
- **Example Request**:
```python
def select_objects(image_path, selection_type='person'):
    url = 'https://api.pixelcut.ai/object-selection'
    headers = {
        'Authorization': 'Bearer YOUR_API_KEY'
    }
    
    files = {
        'image': ('image.jpg', open(image_path, 'rb'), 'image/jpeg')
    }
    
    data = {
        'selection_type': selection_type,
        'multiple': True
    }
    
    response = requests.post(url, headers=headers, files=files, data=data)
    return response.json()
```

### Image Generation
#### Background Generation
- **Endpoint**: `POST /generate-background`
- **Description**: Generate AI backgrounds
- **Parameters**:
  - `prompt` (required): Text description of desired background
  - `style` (optional): Visual style (realistic/artistic/abstract)
  - `aspect_ratio` (optional): Output aspect ratio
  - `resolution` (optional): Output resolution
- **Example Request**:
```python
def generate_background(prompt, style='realistic'):
    url = 'https://api.pixelcut.ai/generate-background'
    headers = {
        'Authorization': 'Bearer YOUR_API_KEY'
    }
    
    data = {
        'prompt': prompt,
        'style': style,
        'aspect_ratio': '16:9'
    }
    
    response = requests.post(url, headers=headers, json=data)
    return response.json()
```

## Response Formats

### Success Response
```json
{
    "success": true,
    "data": {
        "url": "string",
        "width": "number",
        "height": "number",
        "format": "string",
        "size": "number",
        "processing_time": "number"
    },
    "metadata": {
        "original_filename": "string",
        "output_format": "string",
        "processing_options": {}
    }
}
```

### Error Response
```json
{
    "success": false,
    "error": {
        "code": "string",
        "message": "string",
        "details": {}
    }
}
```

## Common Use Cases

### E-commerce Product Photography
```python
def process_product_image(image_path, background_color='white'):
    # 1. Remove background
    result = remove_background(image_path)
    
    # 2. Replace with white background
    processed = replace_background(
        result['data']['url'],
        background_color,
        blend_mode='normal'
    )
    
    # 3. Enhance image quality
    final = enhance_image(
        processed['data']['url'],
        enhancement_type='quality',
        strength=70
    )
    
    return final
```

### Portrait Editing
```python
def process_portrait(image_path):
    # 1. Remove background
    no_bg = remove_background(image_path)
    
    # 2. Add artistic background
    with_bg = replace_background(
        no_bg['data']['url'],
        generate_background('abstract colorful gradient')['data']['url']
    )
    
    # 3. Enhance portrait
    final = enhance_portrait(
        with_bg['data']['url'],
        skin_smoothing=40,
        eye_enhancement=True
    )
    
    return final
```

### Batch Processing
```python
def batch_process_images(image_paths, process_type='background_removal'):
    results = []
    
    for path in image_paths:
        try:
            if process_type == 'background_removal':
                result = remove_background(path)
            elif process_type == 'enhancement':
                result = enhance_image(path)
            results.append({
                'path': path,
                'success': True,
                'result': result
            })
        except Exception as e:
            results.append({
                'path': path,
                'success': False,
                'error': str(e)
            })
    
    return results
```

## Error Handling
```python
def safe_api_call(func):
    def wrapper(*args, **kwargs):
        try:
            response = func(*args, **kwargs)
            
            if response.status_code == 429:
                time.sleep(30)  # Rate limit backoff
                return func(*args, **kwargs)
                
            response.raise_for_status()
            return response.json()
            
        except requests.exceptions.RequestException as e:
            print(f"API call failed: {str(e)}")
            return None
            
        except Exception as e:
            print(f"Unexpected error: {str(e)}")
            return None
            
    return wrapper
```

## Best Practices
1. Image Preparation
   - Optimize image size before upload (max 25MB)
   - Use recommended formats (JPEG, PNG)
   - Ensure adequate resolution (min 512px)
   - Check image aspect ratio

2. Performance Optimization
   - Cache processed images
   - Use appropriate compression
   - Implement parallel processing
   - Monitor API usage

3. Error Handling
   - Implement retry logic
   - Handle rate limits
   - Validate input images
   - Check response status

4. Security
   - Secure API key storage
   - Validate user uploads
   - Implement access control
   - Monitor usage patterns

## Rate Limits
- Free tier: 100 requests/hour
- Basic tier: 1000 requests/hour
- Pro tier: 10000 requests/hour
- Enterprise: Custom limits

## Integration Tips
1. Implement webhook support for long-running processes
2. Use background jobs for batch processing
3. Cache frequently used backgrounds
4. Implement progress tracking
5. Add result validation
