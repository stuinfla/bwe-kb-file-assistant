# ImgBB API Documentation

## Overview
ImgBB is a free image hosting and sharing service that provides a robust API for image upload, management, and retrieval. This documentation covers all aspects of integrating with ImgBB's API services.

## Authentication
```python
import os
import requests

API_KEY = os.environ.get('IMGBB_API_KEY')
BASE_URL = 'https://api.imgbb.com/1/'
```

## API Endpoints

### 1. Image Upload
```python
def upload_image(image_path, expiration=None):
    with open(image_path, 'rb') as image_file:
        payload = {
            'key': API_KEY,
            'image': image_file.read(),
            'expiration': expiration  # in seconds
        }
        response = requests.post(
            f"{BASE_URL}upload",
            files=payload
        )
        return response.json()
```

### 2. Image Management
```python
def delete_image(delete_url):
    response = requests.delete(delete_url, headers={
        'Authorization': f'Bearer {API_KEY}'
    })
    return response.json()

def get_image_info(image_id):
    response = requests.get(
        f"{BASE_URL}images/{image_id}",
        params={'key': API_KEY}
    )
    return response.json()
```

## Error Handling
```python
class ImgBBError(Exception):
    pass

def handle_imgbb_response(response):
    if response.status_code != 200:
        error_msg = response.json().get('error', {}).get('message', 'Unknown error')
        raise ImgBBError(f"API Error: {error_msg}")
    return response.json()

def safe_upload_image(image_path):
    try:
        response = upload_image(image_path)
        return handle_imgbb_response(response)
    except FileNotFoundError:
        raise ImgBBError("Image file not found")
    except requests.RequestException as e:
        raise ImgBBError(f"Network error: {str(e)}")
```

## Rate Limits
- Free tier: 100 uploads per hour
- Pro tier: 1000 uploads per hour
- Enterprise: Custom limits

## Best Practices

### 1. Image Optimization
```python
from PIL import Image
import io

def optimize_image_for_upload(image_path, max_size_kb=1024):
    img = Image.open(image_path)
    
    # Convert to RGB if necessary
    if img.mode in ('RGBA', 'P'):
        img = img.convert('RGB')
    
    # Initial quality
    quality = 95
    output = io.BytesIO()
    
    while quality > 5:
        output.seek(0)
        output.truncate()
        img.save(output, format='JPEG', quality=quality)
        if len(output.getvalue()) <= max_size_kb * 1024:
            break
        quality -= 5
    
    return output.getvalue()
```

### 2. Secure Upload Implementation
```python
def secure_upload(image_path):
    # Validate file type
    allowed_types = {'png', 'jpg', 'jpeg', 'gif'}
    file_type = image_path.split('.')[-1].lower()
    
    if file_type not in allowed_types:
        raise ValueError(f"Unsupported file type: {file_type}")
    
    # Check file size
    if os.path.getsize(image_path) > 32 * 1024 * 1024:  # 32MB limit
        raise ValueError("File too large")
    
    # Optimize and upload
    optimized_image = optimize_image_for_upload(image_path)
    return upload_image(optimized_image)
```

## Common Use Cases

### 1. Bulk Upload with Progress
```python
def bulk_upload(image_paths, callback=None):
    results = []
    total = len(image_paths)
    
    for index, path in enumerate(image_paths, 1):
        try:
            result = secure_upload(path)
            results.append(result)
            
            if callback:
                callback(index / total * 100)
        except Exception as e:
            results.append({'error': str(e), 'path': path})
    
    return results
```

### 2. Image Gallery Integration
```python
def create_gallery(image_paths):
    gallery_urls = []
    
    for path in image_paths:
        response = secure_upload(path)
        if response.get('data'):
            gallery_urls.append({
                'url': response['data']['url'],
                'thumbnail': response['data']['thumb']['url'],
                'delete_url': response['data']['delete_url']
            })
    
    return gallery_urls
```

## Response Formats
```json
{
    "data": {
        "id": "2ndCYJK",
        "url": "https://i.ibb.co/2ndCYJK/example.jpg",
        "delete_url": "https://ibb.co/2ndCYJK/670eb14b-b9c2-4ff9-8d8f-cc9f5b736daa",
        "title": "example.jpg",
        "time": "1683042833",
        "expiration": null,
        "image": {
            "filename": "example.jpg",
            "name": "example",
            "mime": "image/jpeg",
            "extension": "jpg",
            "url": "https://i.ibb.co/2ndCYJK/example.jpg"
        },
        "thumb": {
            "filename": "example.jpg",
            "name": "example",
            "mime": "image/jpeg",
            "extension": "jpg",
            "url": "https://i.ibb.co/2ndCYJK/example_thumb.jpg"
        }
    },
    "success": true,
    "status": 200
}
```

## Security Considerations
1. Always use environment variables for API keys
2. Implement file type validation
3. Set appropriate expiration times
4. Use HTTPS for all requests
5. Implement rate limiting on your end

## Additional Resources
- [Official API Documentation](https://api.imgbb.com/)
- [Developer Portal](https://imgbb.com/developers)
- [Status Page](https://status.imgbb.com/)

## Support
- Email: support@imgbb.com
- API Status: https://status.imgbb.com
- Rate Limits: https://imgbb.com/pricing
