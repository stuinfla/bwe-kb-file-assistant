# OpenAI Assistants API

Base URL: `https://api.openai.com/v1`

## Authentication

**Type:** Bearer Token

Requires an OpenAI API key