#!/bin/bash

# Load environment variables
source .env

# Create new site with BWE naming convention
echo "Creating new BWE site..."
SITE_ID=$(curl -s -X POST \
  -H "Authorization: Bearer $NETLIFY_AUTH_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"name":"bwe-ai-assistant14"}' \
  https://api.netlify.com/api/v1/sites | jq -r '.site_id')

echo "Site ID: $SITE_ID"

# Deploy the site
echo "Deploying BWE Assistant..."
curl -X POST \
  -H "Authorization: Bearer $NETLIFY_AUTH_TOKEN" \
  -H "Content-Type: application/zip" \
  --data-binary "@bwe-assist-deploy.zip" \
  "https://api.netlify.com/api/v1/sites/$SITE_ID/deploys"

# Set environment variables
echo "Setting BWE environment variables..."
curl -X PATCH \
  -H "Authorization: Bearer $NETLIFY_AUTH_TOKEN" \
  -H "Content-Type: application/json" \
  -d "{
    \"env\": {
      \"OPENAI_API_KEY\": \"$OPENAI_API_KEY\",
      \"OPENAI_ASSISTANT_ID\": \"$OPENAI_ASSISTANT_ID\",
      \"OPENAI_VECTOR_STORE_ID\": \"$OPENAI_VECTOR_STORE_ID\"
    }
  }" \
  "https://api.netlify.com/api/v1/sites/$SITE_ID"
